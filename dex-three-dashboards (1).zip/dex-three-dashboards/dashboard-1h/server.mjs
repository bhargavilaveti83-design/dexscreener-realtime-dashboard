import { spawn } from 'node:child_process';
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { createInterface } from 'node:readline';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { FeedState } from './feed-state.mjs';
import { resolveConfig } from './dashboard-config.mjs';
const root = path.dirname(fileURLToPath(import.meta.url));
const config = resolveConfig(JSON.parse(await readFile(path.join(root, 'dashboard.config.json'), 'utf8')));
const state = new FeedState();
let worker, restartTimer, stopping = false;
function startWorker() {
  const executable = process.env.PYTHON || (process.platform === 'win32' ? 'python' : 'python3');
  worker = spawn(executable, ['-u', path.join(root, 'feed_worker.py')], { cwd: root, env: { ...process.env, DEX_ENABLED_TIMINGS: config.enabledTimings.join(',') }, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
  createInterface({ input: worker.stdout }).on('line', line => {
    try { state.update(JSON.parse(line)); } catch { console.error('Feed sent an invalid message; keeping the last valid snapshot.'); }
  });
  worker.stderr.on('data', chunk => { console.error(String(chunk).trim()); });
  worker.on('error', error => state.disconnectAll(`Python worker could not start: ${error.message}. Install Python and run python -m pip install -r requirements.txt.`));
  worker.on('close', code => {
    state.disconnectAll(`Feed worker stopped (${code}). Check the terminal and Python dependencies.`);
    if (!stopping) restartTimer = setTimeout(startWorker, 10000);
  });
  worker.stdin.on('error', error => state.disconnectAll(`Worker input failed: ${error.message}`));
}
function json(res, status, value) {
  res.writeHead(status, { 'Content-Type':'application/json; charset=utf-8', 'Cache-Control':'no-store' });
  res.end(JSON.stringify(value));
}
const allowedFiles = new Map([['/', 'index.html'], ['/index.html','index.html'], ['/style.css','style.css'], ['/app.js','app.js']]);
const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    const tf = url.searchParams.get('timeframe') || config.defaultTimeframe;
    if (url.pathname.startsWith('/api/')) {
      if (url.pathname === '/api/config' && req.method === 'GET') return json(res,200,config);
      if (!config.visibleTimings.includes(tf)) return json(res,400,{error:'Choose 5m, 1h or 24h.'});
      if (!config.enabledTimings.includes(tf)) return json(res,403,{error:'This timing is disabled in this application.'});
      if (url.pathname === '/api/top10' && req.method === 'GET') return json(res,200,state.snapshot(tf));
      if (url.pathname === '/api/health') return json(res,200,{ feeds: Object.fromEntries(config.enabledTimings.map(t=>[t,state.snapshot(t)])) });
      if (url.pathname === '/api/refresh' && req.method === 'POST') {
        if (!worker?.stdin?.writable || worker.exitCode !== null) return json(res,503,{error:'Feed worker is unavailable. Check the terminal.'});
        const revision = state.feeds.get(tf).revision;
        const fresh = state.waitForNew(tf,revision);
        worker.stdin.write(JSON.stringify({ type:'refresh', timeframe:tf })+'\n');
        try { return json(res,200,await fresh); } catch (error) { return json(res,504,{error:error.message}); }
      }
      return json(res,404,{error:'API endpoint not found.'});
    }
    if (req.method !== 'GET') return json(res,405,{error:'Method not allowed.'});
    const file = allowedFiles.get(url.pathname);
    if (!file) { res.writeHead(404); res.end('Not found'); return; }
    const body = await readFile(path.join(root,'public',file));
    const mime = file.endsWith('.css') ? 'text/css' : file.endsWith('.js') ? 'application/javascript' : 'text/html';
    res.writeHead(200,{'Content-Type':mime+'; charset=utf-8','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'}); res.end(body);
  } catch(error) { json(res,500,{error:'Dashboard request failed. Check the server terminal.'}); console.error(error.message); }
});
server.listen(Number(process.env.PORT || config.port),'127.0.0.1',()=>{
  console.log(`Dashboard: http://localhost:${server.address().port}`);
  console.log('Live ranking connection starting. No API key is required by this implementation.');
  startWorker();
});
server.on('error', error=> { console.error(error.code === 'EADDRINUSE' ? 'Port is occupied. Stop the other dashboard or set $env:PORT="3030" before npm start.' : error.message); process.exitCode=1; });
function stop() { stopping=true; clearTimeout(restartTimer); worker?.kill(); server.close(); }
process.on('SIGINT',stop); process.on('SIGTERM',stop);
