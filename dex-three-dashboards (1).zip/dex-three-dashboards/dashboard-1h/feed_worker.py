import os
import asyncio
import json
import struct
import math
import sys
import time
from urllib.parse import quote

HEADERS = {
    "Origin": "https://dexscreener.com",
    "Referer": "https://dexscreener.com/",
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/130.0.0.0 Safari/537.36"
    ),
}

TIMEFRAMES = {
    "5m": ("h24", "trendingScoreM5"),
    "1h": ("h24", "trendingScoreH1"),
    "6h": ("h24", "trendingScoreH6"),
    "24h": ("h24", "trendingScoreH24"),
}

# The server passes only enabled timing windows to the live worker.
_enabled = os.environ.get("DEX_ENABLED_TIMINGS", "5m,1h,24h").split(",")
TIMEFRAMES = {tf: spec for tf, spec in TIMEFRAMES.items() if tf in _enabled}
if not TIMEFRAMES:
    raise ValueError("No supported timing windows enabled")



def emit(payload):
    print(json.dumps(payload, separators=(",", ":"), allow_nan=False), flush=True)


def read_varint(data, offset):
    value = 0
    shift = 0
    while offset < len(data) and shift <= 63:
        byte = data[offset]
        offset += 1
        value |= (byte & 0x7F) << shift
        if byte < 0x80:
            return value, offset
        shift += 7
    raise ValueError("Invalid protobuf varint")


def fields(data):
    result = []
    offset = 0
    while offset < len(data):
        tag, offset = read_varint(data, offset)
        number, wire = tag >> 3, tag & 7
        if number == 0:
            raise ValueError("Invalid protobuf field number")
        if wire == 0:
            value, offset = read_varint(data, offset)
        elif wire == 1:
            if offset + 8 > len(data):
                raise ValueError("Truncated protobuf double")
            value = struct.unpack_from("<d", data, offset)[0]
            offset += 8
        elif wire == 2:
            length, offset = read_varint(data, offset)
            if offset + length > len(data):
                raise ValueError("Truncated protobuf message")
            value = data[offset : offset + length]
            offset += length
        elif wire == 5:
            if offset + 4 > len(data):
                raise ValueError("Truncated protobuf float")
            value = struct.unpack_from("<f", data, offset)[0]
            offset += 4
        else:
            raise ValueError(f"Unsupported protobuf wire type {wire}")
        result.append((number, wire, value))
    return result


def repeated_message(message_fields, number):
    return [
        fields(value)
        for field_number, wire, value in message_fields
        if field_number == number and wire == 2
    ]


def first_string(message_fields, number, default=""):
    for field_number, wire, value in message_fields:
        if field_number == number and wire == 2:
            return value.decode("utf-8", errors="replace")
    return default


def number_field(message_fields, number, default=None):
    for field_number, wire, value in message_fields:
        if field_number == number and wire in (0, 1, 5):
            return value if math.isfinite(value) else default
    return default


def wrapped_number(message_fields, number):
    message = next(iter(repeated_message(message_fields, number)), [])
    return number_field(message, 1)


def timeframe_number(message_fields, parent_number, timeframe_number):
    parent = next(iter(repeated_message(message_fields, parent_number)), [])
    return wrapped_number(parent, timeframe_number)


def token_data(pair_fields, number, default_name):
    token = next(iter(repeated_message(pair_fields, number)), [])
    return {
        "address": first_string(token, 1),
        "name": first_string(token, 2, default_name),
        "symbol": first_string(token, 3, "???"),
    }


def parse_pair(pair_fields):
    chain_id = first_string(pair_fields, 6, "unknown")
    pair_address = first_string(pair_fields, 9)
    profile = next(iter(repeated_message(pair_fields, 26)), [])
    cms_profile = next(iter(repeated_message(pair_fields, 27)), [])
    icon_id = first_string(cms_profile, 2) or first_string(profile, 7)
    h24_txns = next(iter(repeated_message(pair_fields, 14)), [])
    h24_counts = next(iter(repeated_message(h24_txns, 4)), [])
    market_cap = wrapped_number(pair_fields, 23)
    fdv = wrapped_number(pair_fields, 24)
    created_at = next(iter(repeated_message(pair_fields, 25)), [])
    created_seconds = number_field(created_at, 1)
    created_nanos = number_field(created_at, 2)

    price_message = next(iter(repeated_message(pair_fields, 13)), [])
    price_text = first_string(price_message, 1, "")
    try:
        price_usd = float(price_text)
        if not math.isfinite(price_usd):
            price_usd = None
    except (TypeError, ValueError):
        price_usd = None

    return {
        "id": f"{chain_id}:{pair_address}",
        "chainId": chain_id,
        "dexId": first_string(pair_fields, 7, "DEX"),
        "pairAddress": pair_address,
        "url": f"https://dexscreener.com/{quote(chain_id)}/{quote(pair_address)}",
        "iconUrl": (
            f"https://cdn.dexscreener.com/cms/images/{quote(icon_id)}"
            "?width=64&height=64&fit=crop&quality=95&format=auto"
            if icon_id
            else None
        ),
        "baseToken": token_data(pair_fields, 10, "Unknown"),
        "quoteToken": token_data(pair_fields, 11, "Unknown"),
        "priceUsd": price_usd,
        "marketCap": market_cap,
        "fdv": fdv,
        "liquidityUsd": number_field(
            next(iter(repeated_message(pair_fields, 22)), []), 1
        ),
        "volume24h": timeframe_number(pair_fields, 18, 4),
        "transactions24h": (number_field(h24_counts, 1) or 0) + (number_field(h24_counts, 2) or 0) if h24_counts else None,
        "traders24h": number_field(
            next(iter(repeated_message(pair_fields, 17)), []), 4
        ),
        "pairCreatedAt": created_seconds * 1000 + (created_nanos or 0) // 1_000_000 if created_seconds is not None else None,
        "priceChange5m": timeframe_number(pair_fields, 21, 1),
        "priceChange1h": timeframe_number(pair_fields, 21, 2),
        "priceChange6h": timeframe_number(pair_fields, 21, 3),
        "priceChange24h": timeframe_number(pair_fields, 21, 4),
    }


def parse_frame(data):
    envelope = fields(data)
    pairs_message = next(
        (
            value
            for number, wire, value in envelope
            if number == 1 and wire == 2
        ),
        None,
    )
    if pairs_message is None:
        return [], None
    payload = fields(pairs_message)
    stats = next(
        (fields(value) for number, wire, value in payload if number == 1 and wire == 2),
        [],
    )
    stats_24h = next(iter(repeated_message(stats, 4)), [])
    market_stats = {
        "volume24h": number_field(stats_24h, 2),
        "transactions24h": number_field(stats_24h, 1),
    }
    pairs = [
        parse_pair(fields(value))
        for number, wire, value in payload
        if number == 2 and wire == 2
    ]
    return (
        [pair for pair in pairs if pair["pairAddress"] and pair["baseToken"]["address"]][:10],
        market_stats,
    )


async def connect_timeframe(tf, path_tf, rank_key, refresh_event, state):
    from curl_cffi.requests import AsyncSession

    url = f"wss://io.dexscreener.com/dex/screener/v7/pairs/{path_tf}/1?rankBy[key]={rank_key}&rankBy[order]=desc"
    while True:
        session = AsyncSession(headers=HEADERS, impersonate="chrome", timeout=20)
        socket = None
        receive_task = None
        refresh_task = None
        try:
            socket = await session.ws_connect(url, headers=HEADERS)
            state["connected"][tf] = True
            emit({"type": "status", "connected": state["connected"][tf], "timeframe": tf})
            while True:
                receive_task = asyncio.create_task(socket.recv())
                refresh_task = asyncio.create_task(refresh_event.wait())
                done, _pending = await asyncio.wait(
                    (receive_task, refresh_task),
                    return_when=asyncio.FIRST_COMPLETED,
                )
                if refresh_task in done:
                    refresh_event.clear()
                    receive_task.cancel()
                    try:
                        await receive_task
                    except asyncio.CancelledError:
                        pass
                    break
                refresh_task.cancel()
                try:
                    await refresh_task
                except asyncio.CancelledError:
                    pass
                data, _flags = receive_task.result()
                if not data:
                    continue
                if isinstance(data, bytes) and data in (b"ping", b'"ping"'):
                    await socket.send('"pong"')
                    continue
                if isinstance(data, str):
                    if data in ("ping", '"ping"'):
                        await socket.send('"pong"')
                    continue
                try:
                    pairs, market_stats = parse_frame(data)
                except Exception as error:
                    message = f"Could not decode DexScreener {tf} update: {error}"
                    print(message, file=sys.stderr, flush=True)
                    continue
                if pairs:
                    emit({
                        "type": "snapshot",
                        "timeframe": tf,
                        "pairs": pairs,
                        "marketStats": market_stats,
                        "updatedAt": int(time.time() * 1000),
                    })
        except Exception as error:
            message = f"DexScreener connection ({tf}) failed: {error}"
            print(message, file=sys.stderr, flush=True)
            state["connected"][tf] = False
            emit({"type": "status", "connected": state["connected"][tf], "error": message, "timeframe": tf})
        finally:
            state["connected"][tf] = False
            emit({"type": "status", "connected": False, "timeframe": tf})
            for task in (receive_task, refresh_task):
                if task is not None and not task.done():
                    task.cancel()
            if socket is not None:
                try:
                    await socket.close()
                except Exception:
                    pass
            await session.close()
        await asyncio.sleep(4)


async def listen_for_commands(refresh_events):
    while True:
        command = await asyncio.to_thread(sys.stdin.readline)
        if command == "":
            return
        try:
            cmd = json.loads(command)
            if cmd.get("type") == "refresh" and cmd.get("timeframe") in refresh_events:
                refresh_events[cmd["timeframe"]].set()
        except (ValueError, AttributeError):
            continue


async def main():
    state = {"connected": {tf: False for tf in TIMEFRAMES}}
    refresh_events = {tf: asyncio.Event() for tf in TIMEFRAMES}
    command_listener = asyncio.create_task(listen_for_commands(refresh_events))
    tasks = [
        asyncio.create_task(connect_timeframe(tf, p, r, refresh_events[tf], state))
        for tf, (p, r) in TIMEFRAMES.items()
    ]
    try:
        await asyncio.gather(*tasks)
    finally:
        command_listener.cancel()


if __name__ == "__main__":
    asyncio.run(main())
