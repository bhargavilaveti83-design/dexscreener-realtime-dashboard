import test from 'node:test';
import assert from 'node:assert/strict';
import { FeedState } from '../feed-state.mjs';
const pair = address => ({chainId:'solana',pairAddress:address,baseToken:{address:'token'+address,symbol:'SAME'}});
const send=(state,tf,pairs)=>state.update({type:'snapshot',timeframe:tf,pairs});
test('provider order and distinct pools with the same symbol are retained',()=>{
 const state=new FeedState(); send(state,'5m',[pair('b'),pair('a'),pair('b')]);
 assert.deepEqual(state.snapshot('5m').pairs.map(p=>p.pairAddress),['b','a']);
 send(state,'5m',[pair('a'),pair('b')]); assert.equal(state.snapshot('5m').pairs[0].rankChange,1);
});
test('waiting, stale and disconnected snapshots never appear live',()=>{
 let now=100; const state=new FeedState(()=>now);
 assert.equal(state.snapshot('5m').status,'waiting'); send(state,'5m',[pair('a')]);
 assert.equal(state.snapshot('5m').status,'live'); now+=20001; assert.equal(state.snapshot('5m').status,'stale');
 send(state,'5m',[pair('a')]); state.disconnectAll('offline'); assert.equal(state.snapshot('5m').status,'stale');
 assert.equal(state.snapshot('5m').pairs.length,1);
});
test('refresh waits for selected period rather than any update',async()=>{
 const state=new FeedState(); const waiting=state.waitForNew('1h',0,100);
 send(state,'5m',[pair('a')]); send(state,'1h',[pair('b')]);
 assert.equal((await waiting).timeframe,'1h'); assert.equal(state.waiters.size,0);
});
test('refresh timeout rejects and invalid snapshots retain last good data',async()=>{
 const state=new FeedState(); send(state,'5m',[pair('a')]);
 assert.equal(send(state,'5m',[{}]),false); assert.equal(state.snapshot('5m').revision,1);
 await assert.rejects(state.waitForNew('1h',0,10),/No fresh ranking/); assert.equal(state.waiters.size,0);
});
