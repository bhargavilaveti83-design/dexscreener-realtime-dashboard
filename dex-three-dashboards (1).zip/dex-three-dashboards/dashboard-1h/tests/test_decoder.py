import sys, unittest, struct
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from feed_worker import parse_pair, fields, number_field
class DecoderTests(unittest.TestCase):
 def test_missing_metrics_are_not_zero(self):
  pair=parse_pair([])
  for key in ('priceUsd','marketCap','fdv','volume24h','transactions24h','pairCreatedAt'):
   self.assertIsNone(pair[key])
 def test_price_and_cap_are_separate(self):
  pair=parse_pair([(13,2,b'\x0a\x041.25'),(23,2,b'\x09'+struct.pack('<d',100)),(24,2,b'\x09'+struct.pack('<d',200))])
  self.assertEqual(pair['priceUsd'],1.25)
  self.assertEqual(pair['marketCap'],100)
  self.assertEqual(pair['fdv'],200)
 def test_nonfinite_values_are_missing(self):
  self.assertIsNone(number_field([(1,1,float('nan'))],1))
  self.assertIsNone(parse_pair([(13,2,b'\x0a\x03nan')])['priceUsd'])
 def test_truncation_is_rejected(self):
  for payload in (b'\x09\x00',b'\x0a\x05hi',b'\x80'):
   with self.assertRaises(ValueError): fields(payload)
if __name__=='__main__': unittest.main()
