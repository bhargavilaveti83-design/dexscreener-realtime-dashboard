import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
const flush=()=>new Promise(resolve=>setImmediate(resolve));
function element(tf) { return {dataset:tf?{tf}:{},classList:{toggle(){}},listeners:{},setAttribute(){},addEventListener(type,fn){this.listeners[type]=fn;},textContent:'',innerHTML:'',disabled:false}; }
for(const tf of ['5m','1h','24h'])for(const unlocked of [false,true]){
 test(`${tf}: UI timing restrictions with enableAllTimings=${unlocked}`,async()=>{
  const periods=['5m','1h','24h'].map(element),elements=new Map(),requests=[];
  const document={hidden:false,getElementById(id){if(!elements.has(id))elements.set(id,element());return elements.get(id);},querySelectorAll(selector){return selector==='.period'?periods:[];},addEventListener(){}};
  const config={defaultTimeframe:tf,enabledTimings:unlocked?['5m','1h','24h']:[tf]};
  const context=vm.createContext({document,localStorage:{getItem(){return null;}},URL,Intl,Date,AbortSignal,setInterval(){},fetch:async url=>{requests.push(url);return {ok:true,json:async()=>url==='/api/config'?config:{timeframe:new URL(url,'http://localhost').searchParams.get('timeframe'),status:'waiting',pairs:[],marketStats:{},ageMs:null,revision:0}};}});
  vm.runInContext(await readFile(new URL('../public/app.js',import.meta.url),'utf8'),context);
  await flush();await flush();assert.ok(requests.includes('/api/top10?timeframe='+tf));
  for(const button of periods){
   assert.equal(button.disabled,!unlocked&&button.dataset.tf!==tf);
   const prior=requests.length;button.listeners.click();await flush();await flush();
   if(button.disabled)assert.equal(requests.length,prior,'Disabled button must not fetch another ranking');
   else assert.equal(requests.at(-1),'/api/top10?timeframe='+button.dataset.tf);
  }
 });
}
