import test from 'node:test';
import assert from 'node:assert/strict';
import { resolveConfig } from '../dashboard-config.mjs';
for (const tf of ['5m','1h','24h']) {
 test(tf + ': only assigned timing is enabled', () => {
  const c=resolveConfig({defaultTimeframe:tf,enableAllTimings:false,port:3000});
  assert.deepEqual(c.visibleTimings,['5m','1h','24h']);assert.deepEqual(c.enabledTimings,[tf]);
 });
 test(tf + ': one flag enables all three timings', () => {
  const c=resolveConfig({defaultTimeframe:tf,enableAllTimings:true,port:3000});
  assert.deepEqual(c.enabledTimings,['5m','1h','24h']);assert.equal(c.defaultTimeframe,tf);
 });
}
test('invalid configuration is rejected',()=>{
 assert.throws(()=>resolveConfig({defaultTimeframe:'6h',enableAllTimings:false,port:3000}));
 assert.throws(()=>resolveConfig({defaultTimeframe:'5m',enableAllTimings:'false',port:3000}));
});
