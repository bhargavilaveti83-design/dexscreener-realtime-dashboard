export const TIMEFRAMES = ['5m', '1h', '6h', '24h'];
export class FeedState {
  constructor(clock = Date.now) {
    this.clock = clock;
    this.feeds = new Map(TIMEFRAMES.map(tf => [tf, { pairs: [], connected: false, updatedAt: null, revision: 0, error: null, marketStats: {} }]));
    this.waiters = new Set();
  }
  update(message) {
    const feed = this.feeds.get(message.timeframe);
    if (!feed) return false;
    if (message.type === 'status') {
      feed.connected = Boolean(message.connected);
      if (message.error) feed.error = message.error;
      return true;
    }
    if (message.type !== 'snapshot' || !Array.isArray(message.pairs) || !message.pairs.length) return false;
    if (message.pairs.some(p => !p.pairAddress || !p.chainId || !p.baseToken?.address)) return false;
    const prev = new Map(feed.pairs.map(p => [p.id, p]));
    const seen = new Set();
    feed.pairs = message.pairs.filter(p => {
      const id = `${p.chainId}:${p.pairAddress}`;
      if (seen.has(id)) return false;
      seen.add(id); return true;
    }).slice(0, 10).map((p, i) => {
      const id = `${p.chainId}:${p.pairAddress}`, prior = prev.get(id);
      return { ...p, id, rank: i + 1, previousRank: prior?.rank ?? null, rankChange: prior ? prior.rank - i - 1 : null, isNew: prev.size > 0 && !prior };
    });
    feed.updatedAt = this.clock();
    feed.revision++;
    feed.connected = true;
    feed.error = null;
    feed.marketStats = message.marketStats ?? {};
    for (const waiter of [...this.waiters]) waiter();
    return true;
  }
  disconnectAll(error) {
    for (const feed of this.feeds.values()) { feed.connected = false; feed.error = error; }
  }
  snapshot(tf) {
    const feed = this.feeds.get(tf);
    if (!feed) return null;
    const ageMs = feed.updatedAt === null ? null : Math.max(0, this.clock() - feed.updatedAt);
    const stale = ageMs !== null && (ageMs > 20000 || !feed.connected);
    return { ...feed, timeframe: tf, ageMs, stale, status: feed.updatedAt === null ? 'waiting' : stale ? 'stale' : 'live', metricPeriod: '24h', pollIntervalMs: 2000 };
  }
  waitForNew(tf, revision, timeoutMs = 15000) {
    return new Promise((resolve, reject) => {
      const check = () => {
        const feed = this.feeds.get(tf);
        if (feed.revision > revision) { cleanup(); resolve(this.snapshot(tf)); }
      };
      const timer = setTimeout(() => { cleanup(); reject(new Error('No fresh ranking arrived within 15 seconds. Previous data is retained.')); }, timeoutMs);
      const cleanup = () => { clearTimeout(timer); this.waiters.delete(check); };
      this.waiters.add(check); check();
    });
  }
}
