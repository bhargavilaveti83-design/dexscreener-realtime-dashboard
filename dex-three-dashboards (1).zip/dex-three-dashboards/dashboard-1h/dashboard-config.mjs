export const VISIBLE_TIMINGS = ['5m', '1h', '24h'];
export function resolveConfig(raw) {
 if (!VISIBLE_TIMINGS.includes(raw.defaultTimeframe)) throw new Error('Invalid defaultTimeframe in dashboard.config.json');
 if (typeof raw.enableAllTimings !== 'boolean') throw new Error('enableAllTimings must be true or false');
 if (!Number.isInteger(raw.port) || raw.port < 1 || raw.port > 65535) throw new Error('Invalid dashboard port');
 return { ...raw, visibleTimings: VISIBLE_TIMINGS, enabledTimings: raw.enableAllTimings ? [...VISIBLE_TIMINGS] : [raw.defaultTimeframe] };
}
