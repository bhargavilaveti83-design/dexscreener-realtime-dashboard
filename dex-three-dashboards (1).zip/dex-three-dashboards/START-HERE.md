# Three DEX Live Dashboard Applications

| Folder | Working timing | Disabled but visible | Local URL |
| --- | --- | --- | --- |
| dashboard-5m | 5 Min | 1 Hour, 24 Hours | http://localhost:3005 |
| dashboard-1h | 1 Hour | 5 Min, 24 Hours | http://localhost:3001 |
| dashboard-24h | 24 Hours | 5 Min, 1 Hour | http://localhost:3024 |

Open each folder separately in VS Code. In its terminal run `python -m pip install -r requirements.txt`, then `npm start`. To view all three side by side, keep three terminals running and open the URLs above.

Each application has one switch in `dashboard.config.json`: set `enableAllTimings` to `true` and restart to unlock all three timing windows. There is no need to edit UI, server or Python separately.

The shared feed behavior is unchanged: provider ranking order, ten distinct pools, live updates, stale-data labels, selected-period refresh, search, watchlist and comparison. Ranking windows do not mean waiting 5 minutes, one hour or 24 hours to refresh.
