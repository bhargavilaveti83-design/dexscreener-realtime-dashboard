'use strict';
const $ = id => document.getElementById(id);
const rankKeys = { '5m':'trendingScoreM5', '1h':'trendingScoreH1', '6h':'trendingScoreH6', '24h':'trendingScoreH24' };
let dashboardConfig = null;
const state = { tf:'24h', feed:null, view:'trending', query:'', sort:null, direction:-1, inFlight:false, busy:false, sequence:0, saved:new Set(), comparison:new Set(), movements:[] };
try { state.saved = new Set(JSON.parse(localStorage.getItem('dex-live-watchlist') || '[]')); } catch {}
function escapeHtml(value) { return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function finite(n) { return n !== null && n !== undefined && Number.isFinite(Number(n)); }
function compact(n, currency=false) { return finite(n) ? (currency?'$':'')+new Intl.NumberFormat('en-US',{notation:'compact',maximumFractionDigits:2}).format(Number(n)) : '—'; }
function price(n) { if(!finite(n))return '—'; return '$'+new Intl.NumberFormat('en-US',{minimumFractionDigits:0,maximumSignificantDigits:6}).format(Number(n)); }
function percent(n) { return finite(n) ? (Number(n)>0?'+':'')+Number(n).toLocaleString('en-US',{maximumFractionDigits:2})+'%' : '—'; }
function change(n) { return `<td class="${!finite(n)?'unknown':n<0?'negative':'positive'}">${percent(n)}</td>`; }
function age(ms) { if(!finite(ms)||ms<=0)return '—'; const s=Math.max(0,(Date.now()-ms)/1000); return s<3600?Math.floor(s/60)+'m':s<86400?Math.floor(s/3600)+'h':s<2592000?Math.floor(s/86400)+'d':s<31536000?Math.floor(s/2592000)+'mo':Math.floor(s/31536000)+'y'; }
function safeUrl(url) { try { const u=new URL(url); return u.protocol==='https:'?u.href:''; } catch { return ''; } }
function sourceUrl() { return 'https://dexscreener.com/?rankBy='+rankKeys[state.tf]+'&order=desc'; }
function visiblePairs() {
 let pairs=[...(state.feed?.pairs||[])];
 if(state.view==='watchlist')pairs=pairs.filter(p=>state.saved.has(p.id));
 if(state.query)pairs=pairs.filter(p=>(p.baseToken.symbol+' '+p.baseToken.name+' '+p.quoteToken.symbol+' '+p.pairAddress+' '+p.chainId).toLowerCase().includes(state.query));
 if(state.sort)pairs.sort((a,b)=>{ if(!finite(a[state.sort]))return finite(b[state.sort])?1:0;if(!finite(b[state.sort]))return -1;return (Number(a[state.sort])-Number(b[state.sort]))*state.direction; });
 return pairs;
}
function render() {
 const feed=state.feed, pairs=visiblePairs();
 $('watch-count').textContent=state.saved.size;
 $('global-volume').textContent=compact(feed?.marketStats?.volume24h,true);
 $('global-txns').textContent=compact(feed?.marketStats?.transactions24h);
 $('status').className='status '+(feed?.status||'waiting');
 $('status').textContent=feed?.status==='live'?'Live':feed?.status==='stale'?'Stale data':'Connecting';
 const notice=$('notice');
 if(feed?.error||feed?.stale) { notice.className='notice problem';notice.textContent=feed.error||'No recent update has arrived. Displayed values are from the last received snapshot.'; }
 else if(!feed?.pairs?.length) { notice.className='notice';notice.textContent='Waiting for the live ranking. If this continues, check the server terminal and Python dependencies.'; }
 else { notice.className='notice hidden'; }
 $('updated').textContent=feed?.updatedAt?'Received '+new Date(feed.updatedAt).toLocaleTimeString()+' · '+Math.floor(feed.ageMs/1000)+'s ago':'Not synchronized yet';
 $('row-count').textContent=pairs.length+' / '+(feed?.pairs?.length||0)+' pairs';
 $('sort-note').textContent=state.sort?'Custom local sort · Original rank numbers retained':state.view==='watchlist'?'Watchlist within the current Top 10':'Provider ranking order · All chains';
 $('reset-sort').textContent=state.sort?'↺ Restore Trending '+state.tf.toUpperCase():'↓ Trending '+state.tf.toUpperCase();
 $('comparison-period').textContent='Trending '+state.tf.toUpperCase();
 for(const id of ['reference','reference-sidebar'])$(id).href=sourceUrl();
 $('rows').innerHTML=pairs.length?pairs.map(p=>{
 const movement=p.isNew?'NEW':p.rankChange>0?'↑'+p.rankChange:p.rankChange<0?'↓'+Math.abs(p.rankChange):'';
 const logo=safeUrl(p.iconUrl);
 return `<tr><td class="pin token"><div class="pair-cell"><span class="rank-num">#${p.rank}</span><button class="watch ${state.saved.has(p.id)?'saved':''}" data-watch="${escapeHtml(p.id)}" aria-label="Toggle watchlist for ${escapeHtml(p.baseToken.symbol)}">${state.saved.has(p.id)?'★':'☆'}</button>${logo?`<img class="logo" src="${escapeHtml(logo)}" alt="" loading="lazy">`:`<span class="logo logo-letter">${escapeHtml(p.baseToken.symbol.slice(0,2))}</span>`}<div><button class="pair-title" data-detail="${escapeHtml(p.id)}">${escapeHtml(p.baseToken.symbol)}<span class="quote">/ ${escapeHtml(p.quoteToken.symbol)}</span><span class="movement-tag">${movement}</span></button><div class="pair-sub">${escapeHtml(p.chainId)} · ${escapeHtml(p.dexId)}</div></div></div></td><td class="mcap">${compact(p.marketCap,true)}</td><td>${price(p.priceUsd)}</td><td>${age(p.pairCreatedAt)}</td><td>${compact(p.transactions24h)}</td><td>${compact(p.volume24h,true)}</td><td>${compact(p.traders24h)}</td>${change(p.priceChange5m)}${change(p.priceChange1h)}${change(p.priceChange24h)}<td>${compact(p.liquidityUsd,true)}</td></tr>`;
 }).join(''):`<tr><td colspan="11" class="empty">${feed?.pairs?.length?'No matching pairs in this Top 10. Saved pairs outside the current ranking are not fetched.':'Waiting for the first live snapshot…'}</td></tr>`;
 document.querySelectorAll('.logo').forEach(img=>{img.onerror=()=>{img.style.visibility='hidden';};});
 $('movement').innerHTML=state.movements.length?state.movements.slice(0,5).map(m=>`<div class="movement-item"><span>${escapeHtml(m.symbol)} <small class="muted">${escapeHtml(m.chain)}</small></span><span>${escapeHtml(m.message)}</span></div>`).join(''):'Rank changes appear after the next changed snapshot.';
}
async function load() {
 if(state.inFlight)return;
 state.inFlight=true;
 const tf=state.tf, sequence=state.sequence;
 try {
  const response=await fetch('/api/top10?timeframe='+tf,{cache:'no-store',signal:AbortSignal.timeout(8000)});
  const data=await response.json();
  if(!response.ok)throw new Error(data.error||'Dashboard server unavailable.');
  if(sequence!==state.sequence)return;
  const prev=state.feed;
  if(prev?.timeframe===tf&&data.revision!==prev.revision){
   const map=new Map(prev.pairs.map(p=>[p.id,p]));
   for(const p of data.pairs){const old=map.get(p.id);if(!old&&map.size)state.movements.unshift({symbol:p.baseToken.symbol,chain:p.chainId,message:'Entered at #'+p.rank});else if(old&&old.rank!==p.rank)state.movements.unshift({symbol:p.baseToken.symbol,chain:p.chainId,message:'#'+old.rank+' → #'+p.rank});}
   state.movements=state.movements.slice(0,20);
  }
  state.feed=data;render();
 }catch(error){if(sequence===state.sequence){$('notice').className='notice problem';$('notice').textContent=error.message;$('status').className='status stale';$('status').textContent='Server offline';}}
 finally{state.inFlight=false;}
}
async function refresh() {
 if(state.busy)return;state.busy=true;$('refresh').disabled=true;$('refresh').textContent='↻ Waiting…';const tf=state.tf,seq=state.sequence;
 try { const r=await fetch('/api/refresh?timeframe='+tf,{method:'POST',signal:AbortSignal.timeout(18000)}),d=await r.json();if(!r.ok)throw new Error(d.error||'Refresh failed.');if(seq===state.sequence){await load();}}
 catch(e){if(seq===state.sequence){$('notice').className='notice problem';$('notice').textContent=e.message;}}
 finally{state.busy=false;$('refresh').disabled=false;$('refresh').textContent='↻ Refresh';}
}
function pairDetail(id) {
 const p=state.feed?.pairs.find(p=>p.id===id);if(!p)return;
 $('detail-title').textContent=p.baseToken.symbol+' / '+p.quoteToken.symbol;
 const metrics=[['Price',price(p.priceUsd)],['Market cap',compact(p.marketCap,true)],['24h volume',compact(p.volume24h,true)],['Liquidity',compact(p.liquidityUsd,true)],['24h transactions',compact(p.transactions24h)],['24h traders',compact(p.traders24h)],['5m change',percent(p.priceChange5m)],['24h change',percent(p.priceChange24h)]];
 $('detail-content').innerHTML=`<p class="muted">${escapeHtml(p.baseToken.name)} · ${escapeHtml(p.chainId)} · ${escapeHtml(p.dexId)}</p><div class="detail-grid">${metrics.map(([label,val])=>`<div class="detail-item"><span>${label}</span><strong>${val}</strong></div>`).join('')}</div><p class="label">POOL ADDRESS</p><p class="address">${escapeHtml(p.pairAddress)}</p><p class="label">BASE TOKEN ADDRESS</p><p class="address">${escapeHtml(p.baseToken.address)}</p><a class="button reference" target="_blank" rel="noopener noreferrer" href="${escapeHtml(safeUrl(p.url))}">Open this pool in DEX Screener ↗</a>`;
 $('details').showModal();
}
function comparison() {
 const pairs=state.feed?.pairs||[];
 state.comparison=new Set([...state.comparison].filter(id=>pairs.some(p=>p.id===id)));
 $('compare-choices').innerHTML=pairs.map(p=>`<label class="compare-choice"><input type="checkbox" value="${escapeHtml(p.id)}" ${state.comparison.has(p.id)?'checked':''}>${escapeHtml(p.baseToken.symbol)} / ${escapeHtml(p.quoteToken.symbol)}</label>`).join('')||'<p class="muted">Wait for the live ranking before comparing.</p>';
 const selected=pairs.filter(p=>state.comparison.has(p.id));
 const fields=[['Price','priceUsd',price],['Market cap','marketCap',n=>compact(n,true)],['24h volume','volume24h',n=>compact(n,true)],['Liquidity','liquidityUsd',n=>compact(n,true)],['5m change','priceChange5m',percent],['1h change','priceChange1h',percent],['24h change','priceChange24h',percent]];
 $('compare-table').innerHTML=selected.length?`<table><thead><tr><th>METRIC</th>${selected.map(p=>`<th>${escapeHtml(p.baseToken.symbol)} <small>#${p.rank}</small></th>`).join('')}</tr></thead><tbody>${fields.map(([label,key,fmt])=>`<tr><td>${label}</td>${selected.map(p=>`<td>${fmt(p[key])}</td>`).join('')}</tr>`).join('')}</tbody></table>`:'';
}
$('rows').addEventListener('click',e=>{const w=e.target.closest('[data-watch]'),d=e.target.closest('[data-detail]');if(w){const id=w.dataset.watch;state.saved.has(id)?state.saved.delete(id):state.saved.add(id);try{localStorage.setItem('dex-live-watchlist',JSON.stringify([...state.saved]));}catch{}render();}else if(d)pairDetail(d.dataset.detail);});
document.querySelectorAll('.period').forEach(b=>b.addEventListener('click',()=>{if(b.disabled || !dashboardConfig?.enabledTimings.includes(b.dataset.tf))return;state.tf=b.dataset.tf;state.sequence++;state.feed=null;state.sort=null;state.comparison.clear();state.movements=[];document.querySelectorAll('.period').forEach(x=>{x.classList.toggle('active',x===b);x.setAttribute('aria-pressed',String(x===b));});render();load();}));
document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>{state.view=b.dataset.view;document.querySelectorAll('[data-view]').forEach(x=>x.classList.toggle('active',x===b));render();}));
document.querySelectorAll('th[data-sort]').forEach(th=>th.addEventListener('click',()=>{state.direction=state.sort===th.dataset.sort?-state.direction:-1;state.sort=th.dataset.sort;render();}));
$('reset-sort').addEventListener('click',()=>{state.sort=null;render();});
$('search').addEventListener('input',e=>{state.query=e.target.value.trim().toLowerCase();render();});
$('refresh').addEventListener('click',refresh);
$('compare-open').addEventListener('click',()=>{comparison();$('comparison').showModal();});
$('compare-choices').addEventListener('change',e=>{const id=e.target.value;if(e.target.checked){if(state.comparison.size>=3){e.target.checked=false;return;}state.comparison.add(id);}else state.comparison.delete(id);comparison();});
document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>$(b.dataset.close).close()));
document.querySelectorAll('dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}}));
document.addEventListener('visibilitychange',()=>{if(!document.hidden)load();});
async function initialize() {
 try {
  const response = await fetch('/api/config', {cache:'no-store'});
  if (!response.ok) throw new Error('Could not load dashboard settings.');
  dashboardConfig = await response.json();
  state.tf = dashboardConfig.defaultTimeframe;
  document.querySelectorAll('.period').forEach(button => {
   const enabled = dashboardConfig.enabledTimings.includes(button.dataset.tf);
   button.disabled = !enabled;
   button.setAttribute('aria-disabled', String(!enabled));
   button.setAttribute('aria-pressed', String(button.dataset.tf === state.tf));
   button.classList.toggle('active', button.dataset.tf === state.tf);
   button.title = enabled ? '' : 'Disabled in this dashboard';
  });
  render(); await load(); setInterval(load,2000);
 } catch(error) { $('notice').className='notice problem'; $('notice').textContent=error.message; }
}
render();initialize();
