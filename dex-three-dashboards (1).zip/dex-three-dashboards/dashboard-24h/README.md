# DEX Live — 24 Hours Dashboard

This application starts with **24 Hours** as its only working Trending ranking window. All three timing buttons are visible; the other two are disabled. Only the enabled ranking has a live connection. Data API requests for disabled timings are rejected too.

## Start in VS Code (Windows)

Open this application's folder containing `package.json`, then run:

```powershell
python -m pip install -r requirements.txt
npm start
```

Open **http://localhost:3024**. Keep the terminal running. No API key is needed. Each of the three applications has a different default port, so they can run side by side.

## Enable all three timings later — one correction

In `dashboard.config.json`, change:

```json
"enableAllTimings": false
```

to:

```json
"enableAllTimings": true
```

Restart this application's server with Ctrl+C, then `npm start`, and reload the browser. This single change enables all three timing buttons, their live connections, and their API routes. Make the same change in each application's config when you want all three apps unlocked.

The 5 Min / 1 Hour / 24 Hours buttons control Trending rank windows, not scheduled refresh intervals. Live updates continue in every app. Volume, transactions and traders remain 24-hour feed metrics, with 5M, 1H and 24H change columns.

## Feed details and troubleshooting

## Feed and limitations

Based on the supplied teammate's Python curl_cffi connection and protobuf decoder. This is an undocumented website WebSocket feed, not the official public REST API. The official public API does not supply the website Trending order. The connection and binary decoding were successfully tested in this environment; availability on another network and future protocol compatibility cannot be guaranteed. No login cookies are included.

Disconnection retains the last snapshot and marks it stale. Data older than 20 seconds is also marked stale. Refresh succeeds only when a new snapshot arrives for the selected ranking period; otherwise it reports a timeout. The worker reconnects automatically. Empty startup screens contain no fabricated token values.

## Validation

Run `npm test` for provider-order, pool identity, stale-data and refresh-isolation checks. Run `python -m unittest discover -s tests -p "test_*.py"` for decoder tests.

Original feed decoder attribution is retained in LICENSE. The service binds to localhost for local use.

If Python is available as `py`, use `py -m pip install -r requirements.txt` and set `$env:PYTHON="py"` before `npm start`. A missing package.json error means your terminal is in the wrong folder.
